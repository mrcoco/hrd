<?php

// this contains the application parameters that can be maintained via GUI
return array(
    // this is displayed in the header section
    'title' => 'HRD',
    // this is used in error pages
    'adminEmail' => 'wid.pangestu@gmail.com',
    // the copyright information displayed in the footer section
    'copyrightInfo' => 'Copyright &copy; 2012 by <a href="http://www.wirekom.co.id">www.wirekom.co.id</a>.',
    'pdf2swf' => 'pdf2swf',
    'uploads' => '/uploads/',
    'pdf2swf' => 'pdf2swf',
);
