<?php
$this->breadcrumbs = array(
    'Organizations' => array('index'),
    $model->name,
);

$this->menu = array(
    array('label' => 'List Organization', 'url' => array('index')),
    array('label' => 'Create Organization', 'url' => array('create')),
    array('label' => 'Update Organization', 'url' => array('update', 'id' => $model->id)),
    array('label' => 'Delete Organization', 'url' => '#', 'linkOptions' => array('submit' => array('delete', 'id' => $model->id), 'confirm' => 'Are you sure you want to delete this item?')),
    array('label' => 'Manage Organization', 'url' => array('admin')),
);
?>

<h1>View Organization #<?php echo $model->id; ?></h1>

<?php
$this->widget('zii.widgets.CDetailView', array(
    'data' => $model,
    'attributes' => array(
        array(
            'name' => 'major_id',
            'type' => 'raw',
            'value' => CHtml::link(CHtml::encode($model->major->name), array('major/view', 'id' => $model->major->id))
        ),
        'name',
//        'is_vendor',
        array(
            'name' => 'is_vendor',
            'type' => 'raw',
            'value' => ($model->is_vendor ? 'Yes' : 'No')
        ),
//        'id',
//        'created',
//        'updated',
//        'major_id',
    ),
));
?>
