
<?php

$this->widget('zii.widgets.CDetailView', array(
    'data' => $keluarga,
    'attributes' => array(
        'marital_status',
        'jumlah_anak',
//        'created',
//        'updated',
//        'pegawai_id',
    ),
));
?>
